// 
// Decompiled by Procyon v0.5.36
// 

package shipdemo;

public class Port
{
    int x;
    int y;
    String name;
    boolean has_ship;
    
    public Port(final int x, final int y) {
        this.name = "Port";
        this.x = x;
        this.y = y;
        this.has_ship = false;
    }
}
