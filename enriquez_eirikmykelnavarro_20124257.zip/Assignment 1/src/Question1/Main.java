package Question1;

/**
 *
 * @author eirikenriquez
 */
public class Main {

    public static void main(String[] args) {
        GameFrame frame = new GameFrame();
    }
}
